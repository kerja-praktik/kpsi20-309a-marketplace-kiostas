 <style>
 .sidebar a{
  font-size:20px;
}

.sidebar h3{
font-size:25px;
  color:Black;
}
 </style>
           <div class="sidebar"> 
            <form class="form-inline">
                <div  class="dropdown">
                    <div  class="dropdown-menu nav-link nav-dark ml-auto">
                      <h3>Bantuan</h3>
                      <a class="dropdown-item" type="button" href="/bantuan">Cara Mendaftar</a>
                      <a class="dropdown-item" type="button" href="/caraberbelanja">Cara Berbelanja</a>
                      <a class="dropdown-item" type="button" href="/pembayaran">Pembayaran</a>
                      <a class="dropdown-item" type="button" href="/pengiriman">Pengiriman</a>
                      <a class="dropdown-item" type="button" href="/syaratdanketentuan">Syarat dan Ketentuan</a>
                    </div>
                </div>
            </form>
            </div>
