Petunjuk instalasi KIOSTAS:

Requirement:
1. Instalasi XAMPP; anda dapat memperoleh xampp melalui link: https://www.apachefriends.org/download.html 
	Anda akan diminta untuk memilih aplikasi yang mau diinstal. Centang saja semua pilihan dan klik tombol Next.
2. Instalasi Composer; Jikalau anda belum menginstall composer maka lakukan instalasi yang dapat dilakukan secara otomatis dengan 
membuka command prompt di direktori htdocs XAMPP lalu masukkan perintah: 
	"composer install" (tanpa tanda kutip) lalu tekan Enter
3. Instalasi Laravel dengan mengikuti perintah instalasi KIOSTAS

Cara menginstall KIOSTAS:
a. Masuk ke direktori xampp lalu buka folder htdocs
b. Posisikan folder KIOSTAS di folder htdocs di dalam xampp 
c. Masuk ke Command Prompt caranya dengan ketik cmd tepat di direktori htdocs lalu tekan Enter.

d. Mulai proses instalasi KIOSTAS dengan menggunakan perintah ini untuk melakukan request:
	"composer create-project --prefer-dist laravel/laravel KIOSTAS" (tanpa tanda kutip) lalu tekan Enter
Pastikan bahwa koneksi internet dalam keadaan stabil agar tidak terjadi gangguan pada saat proses pengambilan data Laravel KIOSTAS

e. Setelah proses download file KIOSTAS selesai, nantinya akan ada folder baru pada direktori file server dengan nama sesuai nama project yang telah 
Anda tentukan sebelumnya pada folder /xampp/htdocs yaitu folder KIOSTAS

f. Untuk memastikan bahwa KIOSTAS sukses terinstall dan siap untuk digunakan, 
jalankan terlebih dahulu Apache dan MySQL yang ada di XAMPP dengan menekan button Start.

NB:
1. Apabila terdapat error dan Apache tidak bisa running ketika menekan button start Apache xampp control panel. Secara default Apache akan aktif menggunakan port 80
sedangkan tool Mysql menggunakan port 3306. Untuk beberapa kasus, ada kalanya ketika tool-tool tersebut mencoba untuk diaktifkan, program tidak bisa running, 
bahkan muncul pesan informasi ERROR dengan tulisan berwarna merah hal ini bisa disebabkan karena  Adanya aplikasi yang lebih dulu berjalan menggunakan port 80 dan juga port 3306, 
sehingga port bentrok atau crash.
	contoh ERROR:
		Error: Apache shutdown unexpectedly
		This my be due to a blocked port, missing dependencies,
		improver privileges, a crash, or a shutdown by another method.
		Press the log button to view error logs anda check
		the window event Viewer for more clues
		If you need more help, copy and post this
		entire log window on the forums.
Solusi :
	- Klik button Config untuk Apache, kemudian pilih menu Apache (httpd.conf)  
	- Pada dokument text yang terbuka, silahkan cari angka 80, kemudian ganti menjadi 8080, untuk text berikut:
		Listen 80 menjadi Listen 8080
		ServerName localhost:80 menjadi ServerName localhost:8080
	- Simpan perubahan, dan silahkan anda coba restart kembali apache xampp anda.
	- Untuk menjalankan Localhost setelah Ganti Port maka ketika anda ingin mengakses halaman localhost perintahnya
		caranya: Panggil di addressbar pada browser dengan perintah localhost:8080

2. Apabila terdapat error dan MySQL tidak bisa running ketika menekan button start MySQL xampp control panel.
	contoh ERROR:
		12:19:12 PM [mysql] Attempting to start MySQL app...
		12:19:12 PM [mysql] Status change detected: running
		12:19:13 PM [mysql] Status change detected: stopped
		12:19:13 PM [mysql] Error: MySQL shutdown unexpectedly.
		12:19:13 PM [mysql] This may be due to a blocked port, missing dependencies,
		12:19:13 PM [mysql] improper privileges, a crash, or a shutdown by another method
		12:19:13 PM [mysql] Press the Logs button to view error logs and check
		12:19:13 PM [mysql] the Windows Event Viewer for more clues
		12:19:13 PM [mysql] If you need more help, copy and post this
		12:19:13 PM [mysql] entire log window on the forums
Solusi:
	- Stop semua server yang berjalan pada xampp, kemudian exit
	- Masuk ke folder instalasi xampp, kemudia masuk ke folder data, misal pada direktori:
		C:\xampp\mysql\data
	- Temukan file ibdata1, silahkan ganti menjadi ibdata1.bak atau hapus.
	- Coba kembali untuk start MySQL pada control panel xampp 
	- Jika masih tidak bisa berjalan, coba untuk exit dari control panel xampp dengan menekan tanda "X"
	- Aktifkan kembali xampp dengan klik kanan pilih "open as administrator" hal ini mungkin disebabkan oleh block firewall.

g. Pastikan database KIOSTAS sudah tersedia pada database anda dengan membuka tampilan localhost pada browser.
Dengan terlebih dahulu menjalankan "http:localhost" pada browser (tanpa tanda kutip).
Masuk ke menu phpMyAdmin kemudian create database dengan nama "kiostas_db" (tanpa tanda kutip) lalu salin query dari database kiostas_db
yang telah disediakan di dalam folder DB File  Sql ke database kiostas_db yang telah di create tepat di menu SQL phpMyAdmin lalu tekan button GO untuk melakukan eksekusi.
Maka akan terbentuk database yang dibutuhkan dari KIOSTAS. (Pastikan bahwa database berhasil di-create, jika belum terbentuk, lakukan refresh pada halaman tersebut)

h. Selanjutnya arahkan Command Prompt atau Terminal menuju direktori yang telah Anda buat sebelumnya. 
Lalu, masukkan perintah berikut ke dalam Command Prompt atau Terminal:
	"Php artisan" (tanpa tanda kutip) lalu tekan Enter

i. Selanjutnya melakukan migrasi terhadap database yang telah dicreate pada poin g dengan memasukkan perintah: "php artisan migrate". Jika berhasil maka akan muncul 
output bahwa proses migrasi sukses dilakukan.
j. Untuk membuka aplikasi web KIOSTAS, pada Command Prompt masukkan perintah
	"Php artisan serve" (tanpa tanda kutip) lalu tekan Enter.
k. Jika muncul tulisan Laravel development server started pada Command Prompt atau Terminal, langkah selanjutnya adalah membuka link yang telah disediakan.
l. Secara default, Anda akan diarahkan menuju alamat server,yaitu 127.0.0.1:8000. 
m. Silahkan buka alamat server tersebut pada browser seperti Chrome atau Mozilla Firefox. 

Jika muncul seperti pada tampilan dari hompage KIOSTAS maka proses instalasi Laravel Anda telah berhasil.