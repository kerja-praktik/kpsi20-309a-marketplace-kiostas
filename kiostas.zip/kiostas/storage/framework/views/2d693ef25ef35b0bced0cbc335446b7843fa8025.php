<?php $__env->startSection('title','Review Order Page'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div id ="demoFontCOD">
            <h3 class="text-center">PESANAN ANDA SUDAH DITERIMA</h3>
            <p class="text-center">Thanks for your Order that use Options on Cash On Delivery</p>
            <p class="text-center">We will contact you by Your Email (<b><?php echo e($user_order->users_email); ?></b>) or Your Phone Number (<b><?php echo e($user_order->mobile); ?></b>)</p>
        </div>
    </div>
    <div style="margin-bottom: 20px;"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>