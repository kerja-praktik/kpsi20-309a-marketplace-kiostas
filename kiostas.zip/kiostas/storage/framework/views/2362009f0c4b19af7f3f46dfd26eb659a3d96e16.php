<?php $__env->startSection('title','Halaman Admin KIOSTAS'); ?>
<?php $__env->startSection('content'); ?>
    <!--breadcrumbs-->
    <div id="content-header">
        <div id="breadcrumb"> 
        <a href="<?php echo e(url('/admin')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Beranda</a> <a href="#" class="current">Pesanan</a>
        </div>
    </div>
   
    <div class="container-fluid">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-success text-center" role="alert">
                <strong>Berhasil!</strong>
            </div>
        <?php endif; ?>
        <div class="widget-box">
            <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
                <h5>Daftar Pesanan</h5>
            </div>
            <div class="widget-content nopadding">
                <table class="table table-bordered data-table">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>ID Pengguna</th>
                        <th>Email Pengguna</th>
                        <th>Pesanan</th>
                        <th>Metode Pembayaran</th>
                        <th>Total</th>
                        <th>Dibuat Pada</th>
                        <th>Status Pesanan</th>
                        <th>Aksi</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++; ?>
                        <tr class="gradeC">
                            <td><?php echo e($i); ?></td>
                            <td style="vertical-align: middle;"><?php echo e($order->users_id); ?></td>
                            <td style="vertical-align: middle;"><?php echo e($order->users_email); ?></td>
                            <td style="vertical-align: middle;"><?php echo e($order->products_name); ?></td>
                            <td style="vertical-align: middle;"><?php echo e($order->payment_method); ?></td>
                            <td style="vertical-align: middle;">Rp <?php echo e(number_format($order->grand_total, 0, ".", ".")); ?></td>
                            <td style="vertical-align: middle;"><?php echo e($order->created_at); ?></td>
                            <td style="vertical-align: middle;"><?php echo e($order->order_status); ?></td>
                            <td style="text-align: center; vertical-align: middle;">
                                <a href="#myModal<?php echo e($order->id); ?>" data-toggle="modal" class="btn btn-info btn-mini">View</a>
                                <a href="#" class="btn btn-primary btn-mini">Edit</a>
                                <a href="javascript:" rel="<?php echo e($order->id); ?>" rel1="cancel-order" class="btn btn-danger btn-mini deleteRecord">Cancel</a>
                            </td>
                        </tr>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsblock'); ?>
    <script src="<?php echo e(asset('js/excanvas.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.ui.custom.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.flot.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.flot.resize.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.peity.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/fullcalendar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/matrix.js')); ?>"></script>
    <script src="<?php echo e(asset('js/matrix.dashboard.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.gritter.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/matrix.interface.js')); ?>"></script>
    <script src="<?php echo e(asset('js/matrix.chat.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.validate.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.wizard.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.uniform.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/matrix.popover.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/matrix.tables.js')); ?>"></script>
    <script src="<?php echo e(asset('js/matrix.form_validation.js')); ?>"></script>
    <script type="text/javascript">
        // This function is called from the pop-up menus to transfer to
        // a different page. Ignore if the value returned is a null string:
        function goPage (newURL) {

            // if url is empty, skip the menu dividers and reset the menu selection to default
            if (newURL != "") {

                // if url is "-", it is this page -- reset the menu:
                if (newURL == "-" ) {
                    resetMenu();
                }
                // else, send page to designated URL
                else {
                    document.location.href = newURL;
                }
            }
        }

        // resets the menu selection upon entry to this page:
        function resetMenu() {
            document.gomenu.selector.selectedIndex = 2;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>