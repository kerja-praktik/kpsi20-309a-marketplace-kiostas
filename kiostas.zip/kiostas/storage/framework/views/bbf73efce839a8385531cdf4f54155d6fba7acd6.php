<?php $__env->startSection('title','checkOut Page'); ?>
<?php $__env->startSection('slider'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-success text-center" role="alert">
                <?php echo e(Session::get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <form action="<?php echo e(url('/submit-checkout')); ?>" method="post" class="form-horizontal">
                <div class="col-sm-4 col-sm-offset-1">
                    <div class="login-form"><!--login form-->
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <legend>PENGIRIM</legend>
                        <div class="form-group <?php echo e($errors->has('billing_name')?'has-error':''); ?>">
                            <input type="text" class="form-control" name="billing_name" id="billing_name" value="<?php echo e($user_login->name); ?>" placeholder="Nama Pengirim">
                            <span class="text-danger"><?php echo e($errors->first('billing_name')); ?></span>
                        </div>
                        <div class="form-group <?php echo e($errors->has('billing_address')?'has-error':''); ?>">
                            <input type="text" class="form-control" value="<?php echo e($user_login->address); ?>" name="billing_address" id="billing_address" placeholder="Alamat Pengirim">
                            <span class="text-danger"><?php echo e($errors->first('billing_address')); ?></span>
                        </div>
                        <div class="form-group <?php echo e($errors->has('billing_city')?'has-error':''); ?>">
                            <input type="text" class="form-control" name="billing_city" value="<?php echo e($user_login->city); ?>" id="billing_city" placeholder="Kota Pengirim">
                            <span class="text-danger"><?php echo e($errors->first('billing_city')); ?></span>
                        </div>
                        <div class="form-group">
                            <select name="billing_province" id="billing_province" class="form-control">
                                <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($province->province_name); ?>" <?php echo e($user_login->province==$province->province_name?' selected':''); ?>><?php echo e($province->province_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <select name="billing_country" id="billing_country" class="form-control">
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->country_name); ?>" <?php echo e($user_login->country==$country->country_name?' selected':''); ?>><?php echo e($country->country_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group <?php echo e($errors->has('billing_postal_code')?'has-error':''); ?>">
                            <input type="text" class="form-control" name="billing_postal_code" value="<?php echo e($user_login->postal_code); ?>" id="billing_postal_code" placeholder="Kode POS Pengirim">
                            <span class="text-danger"><?php echo e($errors->first('billing_postal_code')); ?></span>
                        </div>
                        <div class="form-group <?php echo e($errors->has('billing_mobile')?'has-error':''); ?>">
                            <input type="text" class="form-control" name="billing_mobile" value="<?php echo e($user_login->mobile); ?>" id="billing_mobile" placeholder="Nomor Handphone Pengirim">
                            <span class="text-danger"><?php echo e($errors->first('billing_mobile')); ?></span>
                        </div>
                    </div><!--/login form-->
                </div>
                <div class="col-sm-1">

                </div>
                <div class="col-sm-4">
                    <div class="signup-form"><!--sign up form-->
                        <legend>PENERIMA</legend>
                        <div class="form-group <?php echo e($errors->has('shipping_name')?'has-error':''); ?>">
                            <input type="text" class="form-control" name="shipping_name" id="shipping_name" value="" placeholder="Nama Penerima">
                            <span class="text-danger"><?php echo e($errors->first('shipping_name')); ?></span>
                        </div>
                        <div class="form-group <?php echo e($errors->has('shipping_address')?'has-error':''); ?>">
                            <input type="text" class="form-control" value="" name="shipping_address" id="shipping_address" placeholder="Alamat Penerima">
                            <span class="text-danger"><?php echo e($errors->first('shipping_address')); ?></span>
                        </div>
                        <div class="form-group <?php echo e($errors->has('shipping_city')?'has-error':''); ?>">
                            <input type="text" class="form-control" name="shipping_city" value="" id="shipping_city" placeholder="Kota Penerima">
                            <span class="text-danger"><?php echo e($errors->first('shipping_city')); ?></span>
                        </div>
                        <div class="form-group">
                            <select name="shipping_province" id="shipping_province" class="form-control">
                                <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($province->province_name); ?>"><?php echo e($province->province_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <select name="shipping_country" id="shipping_country" class="form-control">
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->country_name); ?>"><?php echo e($country->country_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group <?php echo e($errors->has('shipping_postal_code')?'has-error':''); ?>">
                            <input type="text" class="form-control" name="shipping_postal_code" value="<?php echo e($user_login->postal_code); ?>" id="shipping_postal_code" placeholder="Kode POS Penerima">
                            <span class="text-danger"><?php echo e($errors->first('shipping_postal_code')); ?></span>
                        </div>
                        <div class="form-group <?php echo e($errors->has('shipping_mobile')?'has-error':''); ?>">
                            <input type="text" class="form-control" name="shipping_mobile" value="" id="shipping_mobile" placeholder="Nomor Telepon Penerima">
                            <span class="text-danger"><?php echo e($errors->first('shipping_mobile')); ?></span>
                        </div>
                        
                        <button type="submit" class="btn btn-primary" style="float: right;">Beli</button>
                    </div><!--/sign up form-->
                </div>
            </form>
        </div>
    </div>
    <div style="margin-bottom: 20px;"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>