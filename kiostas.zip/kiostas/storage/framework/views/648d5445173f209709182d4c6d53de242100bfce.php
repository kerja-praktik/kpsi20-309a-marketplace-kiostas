<!--sidebar-menu-->
<div id="sidebar"><a href="<?php echo e(url('/admin')); ?>" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
    <ul>
        <li<?php echo e($menu_active==1? ' active':''); ?>><a href="<?php echo e(url('/index')); ?>"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
        <li<?php echo e($menu_active==1? ' active':''); ?>> <a href="<?php echo e(url('/admin')); ?>"><i class="icon icon-th-list"></i> <span>Daftar Pesanan</span></a>
        </li>
        <li class="submenu <?php echo e($menu_active==2? ' active':''); ?>"> <a href="#"><i class="icon icon-th-list"></i> <span>Kategori</span></a>
            <ul>
                <li><a href="<?php echo e(url('/admin/category/create')); ?>">Tambah Kategori Baru</a></li>
                <li><a href="<?php echo e(route('category.index')); ?>">Daftar Kategori</a></li>
            </ul>
        </li>
        <li class="submenu <?php echo e($menu_active==3? ' active':''); ?>"> <a href="#"><i class="icon icon-th-list"></i> <span>Produk</span></a>
            <ul>
                <li><a href="<?php echo e(url('/admin/product/create')); ?>">Tambah Produk Baru</a></li>
                <li><a href="<?php echo e(route('product.index')); ?>">Daftar Produk</a></li>
            </ul>
        </li>
    </ul>
</div>
<!--sidebar-menu-->