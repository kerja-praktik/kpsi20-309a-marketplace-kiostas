<?php $__env->startSection('title','Review Order Page'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div id ="demoFontCOD">
        <h1 class="text-center">PESANAN ANDA SUDAH DITERIMA</h3>
        <p class="text-center">Thanks for your Order that use Options on Bank Transafer</p>
        <p class="text-center">Please make a payment to your Virtual Number : 
        <span class ="text-danger"> <b>0868 <?php echo e($user_order->phone_number); ?></b> </span></p>
        <p class="text-center">Go to <a href = "/bantuan">Bantuan </a> for more info</p>

        </div>
    </div>
    <div style="margin-bottom: 400px;"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>