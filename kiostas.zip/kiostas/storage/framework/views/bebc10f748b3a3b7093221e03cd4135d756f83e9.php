<?php $__env->startSection('title','Detai; Produk'); ?>
<?php $__env->startSection('slider'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <?php echo $__env->make('frontEnd.layouts.category_menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="col-sm-9 padding-right">
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-success text-center" role="alert">
                        <?php echo e(Session::get('message')); ?>

                    </div>
                <?php endif; ?>
        <div class="product-details"><!--product-details-->

            <div class="col-sm-5">
                <div class="easyzoom easyzoom--overlay easyzoom--with-thumbnails">
                    <a href="<?php echo e(url('products/large',$detail_product->image)); ?>">
                        <img src="<?php echo e(url('products/small',$detail_product->image)); ?>" alt="" id="dynamicImage"/>
                    </a>
                </div>

                <ul class="thumbnails" style="margin-left: -10px;">
                    <li>
                        <?php $__currentLoopData = $imagesGalleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagesGallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(url('products/large',$imagesGallery->image)); ?>" data-standard="<?php echo e(url('products/small',$imagesGallery->image)); ?>">
                                <img src="<?php echo e(url('products/small',$imagesGallery->image)); ?>" alt="" width="75" style="padding: 8px;">
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </li>
                </ul>
            </div>
            <div class="col-sm-7">
                <form action="<?php echo e(route('addToCart')); ?>" method="post" role="form">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" name="products_id" value="<?php echo e($detail_product->id); ?>">
                    <input type="hidden" name="product_name" value="<?php echo e($detail_product->p_name); ?>">
                    <input type="hidden" name="product_code" value="<?php echo e($detail_product->p_code); ?>">
                    <input type="hidden" name="product_color" value="<?php echo e($detail_product->p_color); ?>">
                    <input type="hidden" name="price" value="<?php echo e($detail_product->price); ?>" id="dynamicPriceInput">
                    <div class="product-information"><!--/product-information-->
                        <img src="<?php echo e(asset('frontEnd/images/product-details')); ?>" class="newarrival" alt="" />
                        <h3><?php echo e($detail_product->p_name); ?></h3>
                        <p>Kode Produk: <?php echo e($detail_product->p_code); ?></p>
                        <span>
                            <select name="size" id="idSize" class="form-control">
                        	<option value="">Pilih Varian</option>
                            <?php $__currentLoopData = $detail_product->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attrs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($detail_product->id); ?>-<?php echo e($attrs->size); ?>"><?php echo e($attrs->size); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </span>
                        <div class="padding-left">
                        <span>
                        <span id="dynamicPriceInput">Rp <?php echo e(number_format($detail_product->price, 0, ".", ".")); ?></span>
                            <label>Kuantitas:</label>
                            <input type="text" name="quantity" value="<?php echo e($totalStock); ?>" id="inputStock"/>
                        </span>
                        </div>
                        <p><b>Ketersediaan:</b>
                            <?php if($totalStock>0): ?>
                                <span id="availableStockInput">Ada</span>
                            <?php else: ?>
                                <span id="availableStockInput">Habis</span>
                            <?php endif; ?>
                            <?php if($totalStock>0): ?>
                            <button type="submit" class="btn btn-default cart" id="buttonAddToCart">
                                <i class="fa fa-shopping-cart"></i>
                                Tambahkan ke keranjang
                                <?php endif; ?>
                            </button>
                        </p>
                    
                    </div>
                </form>

            </div>
        </div><!--/product-details-->

        <div class="category-tab shop-details-tab"><!--category-tab-->
            <div class="col-sm-12">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#details" data-toggle="tab">Deskripsi</a></li>
                    <li><a href="#reviews" data-toggle="tab">Review </a></li>
                </ul>
            </div>
            <div class="tab-content">
                <div class="tab-pane fade active in" id="details" >
                    <?php echo e($detail_product->description); ?>

                </div>

                <div class="tab-pane fade" id="reviews" >
                    <div class="col-sm-12">
                        <ul>
                            <li><a href=""><i class="fa fa-user"></i>Medan</a></li>
                            <li><a href=""><i class="fa fa-clock-o"></i>12:41 PM</a></li>
                            <li><a href=""><i class="fa fa-calendar-o"></i>15 Juli 2020</a></li>
                        </ul>

                        <form action="#">
										<span>
											<input type="text" placeholder="Your Name"/>
											<input type="email" placeholder="Email Address"/>
										</span>
                            <textarea name="" ></textarea>
                            <b>Rating: </b> <img src="<?php echo e(asset('frontEnd/images/product-details/rating.png')); ?>" alt="" />
                            <button type="button" class="btn btn-default pull-right">
                                Submit
                            </button>
                        </form>
                    </div>
                </div>

            </div>
        </div><!--/category-tab-->

        <div class="recommended_items"><!--recommended_items-->
            <h2 class="title text-center">Item Rekomendasi</h2>

            <div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <?php $countChunk=0;?>
                    <?php $__currentLoopData = $relateProducts->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $countChunk++; ?>
                        <div class="item<?php if($countChunk==1){ echo' active';} ?>">
                            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-sm-4">
                                    <div class="product-image-wrapper">
                                        <div class="single-products">
                                            <div class="productinfo text-center">
                                                <img src="<?php echo e(url('/products/small',$item->image)); ?>" alt="" style="width: 150px;"/>
                                                <span>
                                                <h4><?php echo e($item->p_name); ?></h4>
                                                <h2>Rp <?php echo e(number_format($item->price, 0, ".", ".")); ?></h2>
                                                 <a href="<?php echo e(url('/product-detail',$item->id)); ?>" class="btn btn-default cart" id="buttonAddToCart">Detail Produk</a>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
                    <i class="fa fa-angle-left"></i>
                </a>
                <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
                    <i class="fa fa-angle-right"></i>
                </a>
            </div>
        </div><!--/recommended_items-->

    </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>