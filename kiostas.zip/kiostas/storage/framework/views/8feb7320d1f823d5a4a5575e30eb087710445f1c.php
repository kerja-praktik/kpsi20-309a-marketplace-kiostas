<?php $__env->startSection('title','Review Order Page'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div id ="demoFontCOD">
        <h3 class="text-center">PESANAN ANDA SEDANG KAMI PROSES</h3>
            <p class="text-center">Terima Kasih Telah Memesan Dengan Metode Pembayaran Transfer Bank</p>
            <p class="text-center">Kami akan menghubungi email anda (<b><?php echo e($user_order->users_email); ?></b>) atau nomor telepon anda (<b><?php echo e($user_order->mobile); ?></b>)</p>
            <p class="text-center">Silahkan lihat <a href = "/pembayaran">Bantuan </a> untuk informasi lebih lanjut</p>

        </div>
    </div>
    <div style="margin-bottom: 350px;"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>