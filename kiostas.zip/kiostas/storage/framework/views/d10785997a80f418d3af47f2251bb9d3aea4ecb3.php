<?php $__env->startSection('title','Review Order Page'); ?>
<?php $__env->startSection('slider'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="step-one">
            <h2 class="heading">PENERIMA</h2>
        </div>
        <div class="row">
            <form action="<?php echo e(url('/submit-order')); ?>" method="post" class="form-horizontal">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                <input type="hidden" name="users_id" value="<?php echo e($shipping_address->users_id); ?>">
                <input type="hidden" name="users_email" value="<?php echo e($shipping_address->users_email); ?>">
                <input type="hidden" name="name" value="<?php echo e($shipping_address->name); ?>">
                <input type="hidden" name="address" value="<?php echo e($shipping_address->address); ?>">
                <input type="hidden" name="city" value="<?php echo e($shipping_address->city); ?>">
                <input type="hidden" name="province" value="<?php echo e($shipping_address->province); ?>">
                <input type="hidden" name="postal_code" value="<?php echo e($shipping_address->postal_code); ?>">
                <input type="hidden" name="country" value="<?php echo e($shipping_address->country); ?>">
                <input type="hidden" name="mobile" value="<?php echo e($shipping_address->mobile); ?>">
                <input type="hidden" name="shipping_charges" value="30000">
                <input type="hidden" name="order_status" value="sukses">
                <input type="hidden" name="grand_total" value="<?php echo e($total_price); ?>">
                

                <div class="col-sm-12">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Alamat</th>
                                <th>Kota</th>
                                <th>Provinsi</th>
                                <th>Negara</th>
                                <th>Kode Pos</th>
                                <th>Nomor Telepon</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td><?php echo e($shipping_address->name); ?></td>
                                <td><?php echo e($shipping_address->address); ?></td>
                                <td><?php echo e($shipping_address->city); ?></td>
                                <td><?php echo e($shipping_address->province); ?></td>
                                <td><?php echo e($shipping_address->country); ?></td>
                                <td><?php echo e($shipping_address->postal_code); ?></td>
                                <td><?php echo e($shipping_address->mobile); ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <section id="cart_items">
                        <div class="review-payment">
                            <h2>Review & Pembayaran</h2>
                        </div>
                        <div class="table-responsive cart_info">
                            <table class="table table-condensed">
                                <thead>
                                <tr class="cart_menu">
                                    <td class="image" width="180px">Item</td>
                                    <td class="description" width="250px">Deskripsi</td>
                                    <td class="price" width="180px">Harga</td>
                                    <td class="quantity" width="70px">Kuantitas</td>
                                    <td class="total" width="280px">Total</td>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $cart_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    $image_products=DB::table('products')->select('image')->where('id',$cart_data->products_id)->get();
                                    ?>
                                    <tr>
                                    <td class="cart_product">
                                        <?php $__currentLoopData = $image_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href=""><img src="<?php echo e(url('products/small',$image_product->image)); ?>" alt="" style="width: 100px;"></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td class="cart_description">
                                        <h4><a href=""><?php echo e($cart_data->product_name); ?></a></h4>
                                        <p><?php echo e($cart_data->product_code); ?> | <?php echo e($cart_data->size); ?></p>
                                    </td>
                                    <td class="cart_price">
                                        <p>Rp<?php echo e(number_format($cart_data->price, 0, ".", ".")); ?></p>
                                    </td>
                                    <td class="cart_quantity">
                                        <p><?php echo e($cart_data->quantity); ?></p>
                                    </td>
                                    <td class="cart_total">
                                        <p class="cart_total_price">Rp <?php echo e(number_format($cart_data->price*$cart_data->quantity, 0, ".", ".")); ?></p>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="4">&nbsp;</td>
                                    <td colspan="2">
                                        <table class="table table-condensed total-result">
                                            <tr>
                                                <td>Sub Total</td>
                                                <td>Rp <?php echo e(number_format($cart_data->price*$cart_data->quantity, 0, ".", ".")); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Ongkos Kirim</td>
                                                <td>Rp 30.000</td>
                                            </tr>
                                                <tr>
                                                    <td>Total</td>
                                                    <td><span>Rp <?php echo e(number_format($total_price ,0,".",".")); ?></span></td>
                                                </tr>
                                        </table>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="payment-options">
                            <span>Pilih Metode Pembayaran : </span>
                        <span>
                            <label><input type="radio" name="payment_method" value="COD" checked> Bayar di Tempat</label>
                        </span>
                        <span>
                            <label><input type="radio" name="payment_method" value="banktransfer"> Transfer Bank</label>
                        </span>
                            <button type="submit" class="btn btn-primary" style="float: right;">Pesan</button>
                        </div>
                    </section>

                </div>
            </form>
        </div>
    </div>
    <div style="margin-bottom: 20px;"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>