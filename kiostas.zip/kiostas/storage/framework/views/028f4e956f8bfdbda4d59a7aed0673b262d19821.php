
    <div class="header-middle"><!--header-middle-->
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="logo pull-left">
                        <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('frontEnd/images/home/Kiosta.png')); ?>" alt="Image" height="65" width="260"></a>
                    </div>
                    <div class="btn-group pull-right">
                        <div class="btn-group">
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="shop-menu pull-right">
                        <ul class="nav navbar-nav">
                            <li><a href="<?php echo e(url('/viewcart')); ?>"><i class="fa fa-shopping-cart"></i> Keranjang</a></li>
                            <?php if(Auth::check()): ?>
                                <li><a href="<?php echo e(url('/myaccount')); ?>"><i class="fa fa-user"></i> Akun</a></li>
                                <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-lock"></i> Keluar </a>
                                </li>
                            <?php else: ?>
                                <li><a href="<?php echo e(url('/login_page')); ?>"><i class="fa fa-lock"></i> Masuk</a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-question-circle"></i> Bantuan</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div><!--/header-middle-->

    <div class="header-bottom"><!--header-bottom-->
        <div class="container">
            <div class="row">
                <div class="col-sm-9">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="search_box pull-right">
                        <div class= "serach_box icon">
                        <input type="text" placeholder="Cari Produk"/>
                    </div>
                </div>
            </div>
        </div>
    </div><!--/header-bottom-->
</header><!--/header-->